Geraniums Pot - Intersecting Circles Puzzles Simulator

This is a simulator of the famous "Geraniums" puzzle.
this is a small python program that uses the pygame library

home page: https://github.com/grigorusha/GeraniumsPot

forum page with my other Puzzle simulators - https://twistypuzzles.com/forum/viewtopic.php?p=424143#p424143

You can create a text file with a script-puzzle that describes the location of circles.
I have created files for all the Intersecting circles puzzles, you can download them from the "Garden" folder.
